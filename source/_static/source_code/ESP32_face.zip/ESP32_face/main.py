from time import sleep_ms
from machine import Pin , I2C
import struct

'''
人脸识别：识别到人脸
'''

ESP32CAM_ADDR = 0x52
ESP32CAM_FACE = 0x01
ESP32CAM_LED = 0x11


if __name__ == "__main__":
  iic = I2C(0, scl=Pin(23), sda=Pin(22), freq=100000)
  sleep_ms(1000)

  while True:
    rec = iic.readfrom_mem(ESP32CAM_ADDR , ESP32CAM_FACE , 8)
    if len(rec) >= 8:
      values = struct.unpack('<hhhh', rec)
      if values[2] > 0:
        print("find face")
        iic.readfrom_mem(ESP32CAM_ADDR , ESP32CAM_FACE , 8)
        sleep_ms(100)
    sleep_ms(100)





