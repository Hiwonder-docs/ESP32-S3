from time import sleep_ms
from machine import Pin , I2C


'''
颜色识别：ESP32Cam识别2种颜色
'''

ESP32CAM_ADDR = 0x52
ESP32CAM_COLOR_1 = 0x00
ESP32CAM_COLOR_2 = 0x01
ESP32CAM_LED = 0x11



if __name__ == "__main__":
  iic = I2C(0, scl=Pin(23), sda=Pin(22), freq=100000)
  sleep_ms(1000)

  while True:
    rec1 = iic.readfrom_mem(ESP32CAM_ADDR , ESP32CAM_COLOR_1 , 8) #读取颜色1
    sleep_ms(50)
    rec2 = iic.readfrom_mem(ESP32CAM_ADDR , ESP32CAM_COLOR_2 , 8) #读取颜色2
    if len(rec1) >= 4 and rec1[2] > 0:
        print("COLOR 1")
    elif len(rec2) >= 4 and rec2[2] > 0:
        print("COLOR 2")
    sleep_ms(500)







